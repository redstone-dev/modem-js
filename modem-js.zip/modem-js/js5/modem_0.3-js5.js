/*
	© 2020 redstone2010
	Open source.

	Current version: 0.3-JS-5
	npm and Yarn releases coming in 1.x
	ES6 version: see es6/modem_0.4.js

	(!) Use the ES6 version if you can. It's more secure, since the 'modem' object
		is a constant, rather than a changeable variable, so nobody can override
		it using the console, add a method to it, then call it and damage the site.
		Also, there are arrow functions, which will break if your browser/device
		doesn't support ES6. In short, you should use the ES6 version.

	(!) This version doesn't have a module installer, so

	(√) If you like Modem.js, make sure to star the GitHub repository,
    	or fork the modem-playground repo and add your own features.
    	If I like it, I might even add some features from it to the
    	modem-playground-mods branch! 
*/
var Components, Component, Elem, WittyMessages, x, y;

WittyMessages = ["Made in Sublime Text!","*shoots an arrow function out of a bow*","function successfulStartup(){ console.log(this) }",
"This is totally not a witty message :3","It is Wednesday my duuudes",":3","Sucess on startup!",
"if (java === javascript){ java.name = javascript.name }","Hungry Family","Modem.js is NOT a library, it is a framework!",
"The developer plays Overwatch.","I'm using a MacBook Air >:3","Are you using Windows?","Made in JS 5!","*dancing squidward*",
"...And remember, the cake is a lie.","How many witty messages are there!?!?","modem_rebuild.js.js.js.js.js.js.js.js.js.js",
"The website is in a seperate folder!","https://scratch.mit.edu/users/redstonelasher2010    <=== Copy and paste into the address bar!",
"Celebrating 7 lines of witty messages!","DEV TIP: To show all the witty messages, call modem.showAllWittyMessages(). They'll appear in the console.",
"Soooooo many methods! Also 8 lines of witty messages >:3","Don't use the old Modem.js, which has a class and constructor. Use this one!",
"Me: 9 lines!\n Other person: Who has 9 lives?\n Me: No one does, except cats!", "It is Thuuursday my duuudes"];

var installer = {
	install: function install(modules){

	}
}

var modem = {
	// Make a specialised 'log' function
	log: function (str) {console.log("Modem.js | " + str)},

	setup: function setup () {
		// Empty everything
		Components = [];
		Component = {};
		Elem = "";
		log(WittyMessages[Math.floor(Math.random() * WittyMessages.length)]); // Display a witty message
	},


	showAllWittyMessages: function showAllWittyMessages() { for (i = 0; i < WittyMessages.length; i++){ log(WittyMessages[i]); } },

	setElement: function setElement(element) { Elem = getElementByID(element); } // Set the element modem.render() uses to render everything
	addComponent: function addComponent(component, label, attrib) { // Create an element to render with modem.render(). The core of modem.js
		Component = {
			name: component,
			text: label,
			attributes: []
		}

		Components.push(component);
	},


	addAttribute: function addAttribute(componentIndex, attrib) { Components[componentIndex].attribute.push(attrib) }, // Add attributes

	$CreateComponentDiv: function $CreateComponentDiv (num) {
		x = document.createElement("DIV");
		x.className = "Component" + num;
		Elem.appendChild(x);
	}

	render: function render() {

		for (i = 0; i < Components.length; i++) {
			$CreateComponentDiv(i);
		}

		for (j = 0; j < Components.length; j++) {
			
		}

	},
}

modem.setup();