/*
	© 2020 redstone2010
	Open source.

	Current version: 0.2

	(i) This version has become outdated. 
		Use the modem_0.4-es.js download instead.
*/
let Components, Component, Elem, x, y;

const WittyMessages = ["Made in Sublime Text!","*shoots an arrow function out of a bow*","function successfulStartup(){ console.log(this) }",
"This is totally not a witty message :3","It is Wednesday my duuudes",":3","Sucess on startup!",
"if (java === javascript){ java.name = javascript.name }","Hungry Family","Modem.js is NOT a library, it is a framework!",
"The developer plays Overwatch.","I'm using a MacBook Air >:3","Are you using Windows?","Made in ES6!","*dancing squidward*",
"...And remember, the cake is a lie.","How many witty messages are there!?!?","modem_rebuild.js.js.js.js.js.js.js.js.js.js",
"The website is in a seperate folder!","https://scratch.mit.edu/users/redstonelasher2010    <=== Copy and paste into the address bar!",
"Celebrating 7 lines of witty messages!","DEV TIP: To show all the witty messages, call internal.showAllWittyMessages(). They'll appear in the console.",
"Soooooo many methods! Also 8 lines of witty messages >:3","Don't use the old Modem.js, which has a class and constructor. Use this one!",
"Me: 9 lines!\n Other person: Who has 9 lives?\n Me: No one does, except cats!\n Cat: *Mrows in affirmation*"];

const internal = {
	$CreateComponentDiv: (num) => {
		x = document.createElement("DIV");
		x.className = "Component" + num;
		Elem.appendChild(x);
	},

	showAllWittyMessages: () => { for (i = 0; i < WittyMessages.length; i++){ log(WittyMessages[i]); } }
}

const modem = {
	// Make a specialised 'log' function
	log: (str) => console.log("Modem.js | " + str);

	setup: () => {
		// Empty everything
		Components = [];
		Component = {};
		Elem = "";
		log(WittyMessages[Math.floor(Math.random() * WittyMessages.length)]); // Display a witty message
	},

	setElement: (element) => { Elem = getElementByID(element); } // Set the element modem.render() uses to render everything
	addComponent: (component, label, attrib) => { // Create an element to render with modem.render(). The core of modem.js
		Component = {
			name: component,
			text: label,
			attributes: []
		}

		Components.push(component);
	},


	addAttribute: (componentIndex, attrib) => { Components[componentIndex].attribute.push(attrib) }, // Add attributes

	render: () => {

		for (i = 0; i < Components.length; i++) {
			internal.$CreateComponentDiv(i);
		}

		for (j = 0; j < Components.length; j++) {
			
		}

	},
}

modem.setup();