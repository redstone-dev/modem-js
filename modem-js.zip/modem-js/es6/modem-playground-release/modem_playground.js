/*
	Public domain code.

	Current version: 0.3-PL
	Stable release: see modem_0.4.js

	(!) Don't download this release. Instead, download
		the file 'modem_0.4.js'. This release may be
		filled to the brim with bugs.

	(√) This is the playground release. Fork it and add
		your own code!

	(i) I commented out a whole bunch of unnecessary code,
		but you can add it back in. I don't mind :)

	(i) This version also doesn't contain keys, since it's
		not meant to work with the installer, so you have
		to hardcode the modules using 'import "x"' statements.

*/
let Components, Component, Elem, x, y;

/*

As I said above, you can un-comment this if you want. Just make sure to get rid of the closing
comment.

const WittyMessages = ["Made in Sublime Text!","*shoots an arrow function out of a bow*","function successfulStartup(){ console.log(this) }",
"This is totally not a witty message :3","It is Wednesday my duuudes 🐸",":3","Sucess on startup!",
"if (java === javascript){ java.name = javascript.name }","That's a pretty hungry family.","Modem.js is NOT a library, it is a framework!",
"The developer plays Overwatch.","I'm using a MacBook Air >:3","Are you using Windows?","Made in ES6!","*dancing squidward*",
"...And remember, the cake is a lie.","How many witty messages are there!?!?","modem_rebuild.js.js.js.js.js.js.js.js.js.js",
"The website is in a seperate folder!","https://scratch.mit.edu/users/redstonelasher2010    <=== Copy and paste into the address bar!",
"Celebrating 6 lines of witty messages!","DEV TIP: To show all the witty messages, call modem.showAllWittyMessages(). They'll appear in the console.",
"Soooooo many methods! Also 8 lines of witty messages >:3","Don't use the old Modem.js, which has a class and constructor. Use this one!",
"Me: 8 lines!\n Other person: Who has 9 lives?\n Me: No one does, except cats!", "It is thurrrrzzzdaaayyy my duuudes",
"I wish we could use Markdown in console messages...oh well", "Me can haz npm reweese? Pweez? 🥺", "  ||-//", 
"Cheesecake is good.", "Hey, 10 lines of witty messages!", ""];

*/



const modem = {
	// Make a specialised 'log' function
	log: (str) => console.log("Modem.js | " + str),

	setup: () => {
		// Empty everything
		Components = [];
		Component = {};
		Elem = "";
		// Also removed this since it'll throw an error if WittyMessages is
		// not defined.
		//log(WittyMessages[Math.floor(Math.random() * WittyMessages.length)]);
	},

	// Removed the below arrow function.
	// showAllWittyMessages: () => { for (i = 0; i < WittyMessages.length; i++){ log(WittyMessages[i]); } },

	setElement: (element) => { Elem = getElementByID(element); } // Set the element modem.render() uses to render everything
	addComponent: (component, label, attrib) => { // Create an element to render with modem.render(). The core of modem.js
		Component = {
			name: component,
			text: label,
			attributes: []
		}

		Components.push(component);
	},


	addAttribute: (componentIndex, attrib) => { Components[componentIndex].attribute.push(attrib) }, // Add attributes

	$CreateComponentDiv: (num) => {
		x = document.createElement("DIV");
		x.className = "Component" + num;
		Elem.appendChild(x);
	}

	render: () => {

		for (i = 0; i < Components.length; i++) {
			$CreateComponentDiv(i);
		}

		for (j = 0; j < Components.length; j++) {
			
		}

	},
}

modem.setup();