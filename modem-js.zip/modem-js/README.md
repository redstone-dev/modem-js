# Modem.js
### About
Modem.js is a light and powerful JavaScript UI library 
written in less than 100 lines of code.

### Download
You can download Modem.js directly: <a href="../es6/modem_0.3.js" download>(Click)</a>
And then, insert it into your website folder.

### Setting Up Your Modem.js Program
First, make an HTML file with this code:
````xml
<div id="*YourNameHere*"></div>
````

Then, type this in your JavaScript file:
````javascript
import "../es6/modem.js";

modem.setElement("*YourNameHere*");

````

And that's all you need to set up Modem.js.


### Creation: Creating Components With Modem.js

Adding components to your HTML file with Modem.js is easy. Just use Modem's `addComponent()` method.

